using System;
using System.Collections;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Service.Module;

namespace Service.Controllers
{
    [ApiController]
    public class ExamController : ControllerBase
    {
        [Route("select")]
        [HttpGet]
        public ActionResult<ArrayList> Select()
        {
            Console.WriteLine("Select 실행~");

            DataBase db = new DataBase();
            SqlDataReader sdr = db.Reader("exam_select");
            ArrayList list = new ArrayList();
            while(sdr.Read())
            {
                string[] arr = new string[6];
                for (int i = 0; i < sdr.FieldCount; i++)
                {
                    arr[i] = sdr.GetValue(i).ToString();
                }
                list.Add(arr);
            }
            db.ReaderClose(sdr);

            return list;
        }

        [Route("insert")]
        [HttpPost]
        public ActionResult<string> Insert([FromForm] string subject, [FromForm] string contents, [FromForm] string writer, [FromForm] string pwd, [FromForm] string count)
        {
            string param = string.Format("{0}, {1}, {2}, {3}, {4}", subject, contents, writer, pwd, count);
            Console.WriteLine("Insert : " + param);
            Hashtable ht = new Hashtable();
            ht.Add("@subject", subject);
            ht.Add("@contents", contents);
            ht.Add("@writer", writer);
            ht.Add("@pwd", pwd);
            ht.Add("@count", count);
            DataBase db = new DataBase();
            if(db.NonQuery("exam_insert", ht))
            {
                return "1";
            }
            else 
            {
                return "0";
            }
        }

        [Route("update")]
        [HttpPost]
        public ActionResult<string> Update([FromForm] string num,[FromForm] string contents)
        {
            string param = string.Format("{0}, {1}", num, contents);
            Console.WriteLine("Update : " + param);
            Hashtable ht = new Hashtable();
            ht.Add("@num", num);
            ht.Add("@contents", contents);
            DataBase db = new DataBase();
            if(db.NonQuery("exam_update", ht))
            {
                return "1";
            }
            else 
            {
                return "0";
            }
        }

        [Route("delete")]
        [HttpPost]
        public ActionResult<string> Delete([FromForm] string num)
        {
            string param = string.Format("{0}", num);
            Console.WriteLine("Delete : " + param);
            Hashtable ht = new Hashtable();
            ht.Add("@num", num);
            DataBase db = new DataBase();
            if(db.NonQuery("exam_update", ht))
            {
                return "1";
            }
            else 
            {
                return "0";
            }
        }
    
        
    }
}
