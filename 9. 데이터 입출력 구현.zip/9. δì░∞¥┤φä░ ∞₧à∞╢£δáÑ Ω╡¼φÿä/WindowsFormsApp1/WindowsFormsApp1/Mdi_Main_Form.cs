﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Mdi_Main_Form : Form
    {
        Mdi_Form mdi_main;
        string num;
        public Mdi_Main_Form(Mdi_Form mdi_main, string num)
        {
            InitializeComponent();
            this.mdi_main = mdi_main;
            this.num = num;
        }

        private void Mdi_Main_Form_Paint(object sender, PaintEventArgs e)
        {
            Pen pen = new Pen(Color.FromArgb(255, 0, 0, 0));
            e.Graphics.DrawLine(pen, 0, 40, 600, 40);
            e.Graphics.DrawLine(pen, 0, 300, 600, 300);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // 목록
            this.Close();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // 수정
            mdi_main.mdi_main_form.Hide();
            mdi_main.update_form.Show();
            mdi_main.delete_form.Hide();

        }

        private void button3_Click(object sender, EventArgs e)
        {
            // 삭제
            mdi_main.mdi_main_form.Hide();
            mdi_main.update_form.Hide();
            mdi_main.delete_form.Show();

        }
    }
}
