﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using WindowsFormsApp;

namespace WindowsFormsApp1
{
    public partial class Board_From : Form
    {
        public Board_From()
        {
            InitializeComponent();
            Load += Board_From_Load;
        }

        private void Board_From_Load(object sender, EventArgs e)
        {
            //WebAPI api = new WebAPI();
            WebAPI api = new WebAPI();
            api.ListView(listView1, "http://192.168.3.88:5000/select");
            listView1.MouseClick += listView1_MouseClick;
           
        }

        private void Form1_Paint(object sender, PaintEventArgs e)
        {
            Pen pen = new Pen(Color.FromArgb(255, 0, 0, 0));
            e.Graphics.DrawLine(pen, 70, 80, 746, 80);
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // 검색
        }

        private void listView1_MouseClick(object sender, MouseEventArgs e)
        {
            int index;
            index = listView1.FocusedItem.Index;
            string num = listView1.Items[index].SubItems[0].Text;

            Mdi_Form mdi_form = new Mdi_Form(num);
            mdi_form.StartPosition = FormStartPosition.CenterParent;
            mdi_form.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // 추가            

            Write_Form write_form = new Write_Form();
            write_form.StartPosition = FormStartPosition.CenterParent;
            write_form.ShowDialog();
        }
    }
}
