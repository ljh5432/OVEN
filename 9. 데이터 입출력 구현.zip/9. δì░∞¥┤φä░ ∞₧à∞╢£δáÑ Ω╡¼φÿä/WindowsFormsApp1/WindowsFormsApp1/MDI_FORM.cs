﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Mdi_Form : Form
    {
        public Mdi_Main_Form mdi_main_form;
        public Update_Form update_form;
        public Delete_Form delete_form;

        public Mdi_Form(string num)
        {
            InitializeComponent();
            Load += Mdi_Form_Load;

            mdi_main_form = new Mdi_Main_Form(this, num);
            update_form = new Update_Form(this, num);
            delete_form = new Delete_Form(this, num);
        }

        private void Mdi_Form_Load(object sender, EventArgs e)
        {
            //panel1.BackColor = Color.Red;

            mdi_main_form.TopLevel = false;
            //Child1.TopMost = true;
            mdi_main_form.MdiParent = this;
            mdi_main_form.Dock = DockStyle.Fill; //판넬크기에 맞게 사이즈 늘림.
            panel1.Controls.Add(mdi_main_form);
            mdi_main_form.Show();

            update_form.TopLevel = false;
            update_form.MdiParent = this;
            update_form.Dock = DockStyle.Fill; //판넬크기에 맞게 사이즈 늘림.
            panel1.Controls.Add(update_form);
            update_form.Hide();

            delete_form.TopLevel = false;
            delete_form.MdiParent = this;
            delete_form.Dock = DockStyle.Fill; //판넬크기에 맞게 사이즈 늘림.
            panel1.Controls.Add(delete_form);
            delete_form.Hide();
        }
    }
}
