﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Delete_Form : Form
    {
        Mdi_Form mdi_main;
        string num;
        public Delete_Form(Mdi_Form mdi_main, string num)
        {
            InitializeComponent();
            this.mdi_main = mdi_main;
            this.num = num;
        }

        private void Delete_Form_Paint(object sender, PaintEventArgs e)
        {
            Pen pen = new Pen(Color.FromArgb(255, 0, 0, 0));
            e.Graphics.DrawLine(pen, 0, 40, 600, 40);
            e.Graphics.DrawLine(pen, 0, 310, 600, 310);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // 확인
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // 취소
            mdi_main.mdi_main_form.Show();
            mdi_main.update_form.Hide();
            mdi_main.delete_form.Hide();
        }
    }
}
