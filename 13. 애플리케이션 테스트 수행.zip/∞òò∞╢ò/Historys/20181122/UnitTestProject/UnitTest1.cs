﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Data.SqlClient;
using _20181123;
using DB;
using System.Windows.Forms;
using System.Collections;
using System.Drawing;

namespace UnitTestProject
{
    [TestClass]
    public class UnitTest1
    {

        [TestMethod]
        public void TestMethod1()
        {
            MSsql db = new MSsql();

            Console.WriteLine("");
            Console.WriteLine("================= MSSQL Connection() 및 Close() TEST - START =====================");
            Console.WriteLine("");                       

            // db 연결 테스트
            bool result_con = db.Connection();

            // db 연결종료 테스트
            bool result_con_close = db.ConnectionClose();

            bool result;

            if(result_con && result_con_close)
            {
                result = true;
            }
            else
            {
                result = false;
            }

            Assert.AreEqual(true, result);

            Console.WriteLine("");
            Console.WriteLine("================= MSSQL Connection() 및 Close() TEST - END =====================");
            Console.WriteLine("");
                                   
        }

        [TestMethod]
        public void TestMethod2()
        {
            Console.WriteLine("");
            Console.WriteLine("================= MSSQL DB SELECT 테스트 - START =====================");
            Console.WriteLine("");

            MSsql db = new MSsql();

            string sql = "select* from[Member];";
            SqlDataReader reader = db.Reader(sql);

            bool result;

            if (reader != null)
            {
                result = true;
            }
            else
            {
                result = false;
            }

            Assert.AreEqual(true, result);

            Console.WriteLine("");
            Console.WriteLine("================= MSSQL DB SELECT 테스트 - END =====================");
            Console.WriteLine("");

        }

        [TestMethod]
        public void TestMethod3()
        {
            Console.WriteLine("");
            Console.WriteLine("================= MSSQL DB SELECT Fail 테스트 - START =====================");
            Console.WriteLine("");

            MSsql db = new MSsql();

            string sql = "select* from[Member1];";  // 없는 테이블 조회시 임의로 오류 발생.
            SqlDataReader reader = db.Reader(sql);

            bool result;

            if (reader != null)
            {
                result = true;
            }
            else
            {
                result = false;
            }

            db.ReaderClose(reader);

            Assert.AreEqual(true, result);

            Console.WriteLine("");
            Console.WriteLine("================= MSSQL DB SELECT Fail 테스트 - END =====================");
            Console.WriteLine("");

        }



        // 공통 모듈 테스트

        [TestMethod]
        public void TestMethod4()
        {
            

            Console.WriteLine("");
            Console.WriteLine("================= Commons 공통모듈 테스트 getMdiForm - START =====================");
            Console.WriteLine("");

            MSsql db = new MSsql();

            Main mainForm = new Main();
            mainForm.IsMdiContainer = true;
            mainForm.Size = new Size(1000, 800);
            mainForm.FormBorderStyle = FormBorderStyle.FixedSingle;
            mainForm.MaximizeBox = false;
            mainForm.MinimizeBox = false;
            mainForm.Text = "회원정보";

            UserForm userform = new UserForm(db);

            Commons commons = new Commons();

            Hashtable hashtable = new Hashtable();
            hashtable.Add("size", new Size(1000, 700));
            hashtable.Add("point", new Point(0, 100));
            hashtable.Add("color", Color.Yellow);
            hashtable.Add("name", "contents");
            Panel contents1 = commons.getPanel(hashtable, mainForm);
            Panel contents2 = commons.getPanel(hashtable, mainForm);

            // userform의 MdiParent로 mainForm이 지정되고 contents1 패널에 userform이 컨트롤로 추가된다. 
            Form setuserform = commons.getMdiForm(mainForm, userform, contents1);

            // contents1 패널에 userform이 추가된것 확인. 맞으면 True 틀리면 False 리턴
            Console.WriteLine(" True : " + contents1.Controls.Contains(setuserform)); 
            Console.WriteLine(" False : " + contents2.Controls.Contains(setuserform));

            bool result = contents1.Controls.Contains(setuserform);

            Assert.AreEqual(true, result);



            Console.WriteLine("");
            Console.WriteLine("================= Commons 공통모듈 테스트 getMdiForm - END =====================");
            Console.WriteLine("");

        }

        [TestMethod]
        public void TestMethod5()
        {


            Console.WriteLine("");
            Console.WriteLine("================= Commons 공통모듈 Fail 테스트 getMdiForm - START =====================");
            Console.WriteLine("");

            MSsql db = new MSsql();

            Main mainForm = new Main();
            mainForm.IsMdiContainer = true;
            mainForm.Size = new Size(1000, 800);
            mainForm.FormBorderStyle = FormBorderStyle.FixedSingle;
            mainForm.MaximizeBox = false;
            mainForm.MinimizeBox = false;
            mainForm.Text = "회원정보";

            UserForm userform = new UserForm(db);

            Commons commons = new Commons();

            Hashtable hashtable = new Hashtable();
            hashtable.Add("size", new Size(1000, 700));
            hashtable.Add("point", new Point(0, 100));
            hashtable.Add("color", Color.Yellow);
            hashtable.Add("name", "contents");
            Panel contents1 = commons.getPanel(hashtable, mainForm);
            Panel contents2 = commons.getPanel(hashtable, mainForm);

            // userform의 MdiParent로 mainForm이 지정되고 contents1 패널에 userform이 컨트롤로 추가된다. 
            Form setuserform = commons.getMdiForm(mainForm, userform, contents1);

            // contents1 패널에 userform이 추가된것 확인. 맞으면 True 틀리면 False 리턴
            Console.WriteLine(" True : " + contents1.Controls.Contains(setuserform));
            Console.WriteLine(" False : " + contents2.Controls.Contains(setuserform));

            bool result = contents2.Controls.Contains(setuserform);

            Assert.AreEqual(true, result);



            Console.WriteLine("");
            Console.WriteLine("================= Commons 공통모듈 Fail 테스트 getMdiForm - END =====================");
            Console.WriteLine("");

        }

    }
}
