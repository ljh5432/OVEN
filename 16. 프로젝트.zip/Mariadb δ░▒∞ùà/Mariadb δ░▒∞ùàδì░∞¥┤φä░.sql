-- --------------------------------------------------------
-- 호스트:                          ljh5432.iptime.org
-- 서버 버전:                        10.3.12-MariaDB - MariaDB Server
-- 서버 OS:                        Linux
-- HeidiSQL 버전:                  10.1.0.5464
-- --------------------------------------------------------

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET NAMES utf8 */;
/*!50503 SET NAMES utf8mb4 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;


-- gdc3_2 데이터베이스 구조 내보내기
CREATE DATABASE IF NOT EXISTS `gdc3_2` /*!40100 DEFAULT CHARACTER SET utf8 */;
USE `gdc3_2`;

-- 테이블 gdc3_2.book_info 구조 내보내기
CREATE TABLE IF NOT EXISTS `book_info` (
  `book_number` int(11) NOT NULL AUTO_INCREMENT,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `publisher` varchar(255) NOT NULL,
  `genre` varchar(255) NOT NULL,
  `brief_introduction` varchar(4000) DEFAULT NULL,
  `availability` varchar(255) NOT NULL DEFAULT '가능',
  `lender` varchar(255) NOT NULL DEFAULT 'Non',
  `book_location` varchar(255) NOT NULL,
  `image_location` varchar(255) DEFAULT NULL,
  `image_FileName` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`book_number`)
) ENGINE=InnoDB AUTO_INCREMENT=63 DEFAULT CHARSET=utf8;

-- 테이블 데이터 gdc3_2.book_info:~43 rows (대략적) 내보내기
/*!40000 ALTER TABLE `book_info` DISABLE KEYS */;
INSERT INTO `book_info` (`book_number`, `title`, `author`, `publisher`, `genre`, `brief_introduction`, `availability`, `lender`, `book_location`, `image_location`, `image_FileName`) VALUES
	(1, '이것이 C#이다', '박상현', '한빛미디어', '컴퓨터/IT', '한 번 배울 때 제대로, 기본기부터 탄탄히 다지고 간다!\r\n이 책은 C# .NET 프레임워크 세계에 첫 발을 들이는 입문자를 위한 책이다. 따라서 딱딱하지 않은 대화식 표현으로 1:1 강의처럼 배울 수 있는 것이 이 책의 가장 큰 장점이다. 또한 C#의 핵심 문법은 물론, 프로그래밍 동작 원리까지도 입문자 입장에서 하나하나 꼼꼼히 설명하였다. \r\n책을 덮을 때쯤이면 기초 문법부터, 고급 문법, 그리고 .NET 프레임워크의 활용까지 C#의 전반적인 큰 틀을 자연스레 익힐 수 있을 것이다.\r\n『이것이 C#이다』로 C# 프로그래밍을 시작한다면, 튼튼한 기본기가 갖춰져, 더 이상 실전과 응용도 두렵지 않다! \r\n', '가능', 'Non', 'A열 1-1', 'http://ljh5432.iptime.org:5000/e3976b00-3b8c-4844-8223-4eed565e0e28.png', '이것이 C샵이다.png'),
	(2, '시작하세요 C# 7.1 프로그래밍', '정성태', '위키북스', '컴퓨터/IT', '이 책의 목표는 확실하다. 여러분들이 프로그램을 만들고자 할 때 사용하게 될 프로그래밍 언어인 C#의 기초를 단단하게 다질 수 있도록 이 책을 구성했다. C# 언어를 최신의 7.1 문법까지 설명하고 있으며, 나아가 단순히 언어의 문법 습득에 그치지 않고 실제로 프로그램을 제작할 수 있는 단계까지 학습할 수 있게 내용을 구성했다. ', '가능', 'Non', 'A열 2-1', 'http://ljh5432.iptime.org:5000/be634664-9480-45e8-a22b-571bfc564002.png', '시작하세요 C# 7.1 프로그래밍.png'),
	(3, 'ASp.NET&Core를다루는기술', '박용준', '길벗', '컴퓨터/IT', '기술의 집합체인 ASP.NET을 최신 버전 4.6으로 배운다. .NET 기술을 사용하는 오픈 소스이자 크로스플랫폼인 ASP.NET Core 1.0의 새로운 특징도 학습한다. 특히 ASP.NET Core MVC는 Web Pages, Web API, MVC를 하나로 통합하여 관리할 수 있다. 새로운 Web Forms과 MVC 프레임워크를 한 권으로 익혀 보자. ', '가능', 'Non', 'B열 3-1', 'http://ljh5432.iptime.org:5000/398e4654-ffff-42f4-b8e3-600183f8d3b4.png', 'ASp.NET&Core를다루는기술.png'),
	(7, 'Do it! 점프 투 파이썬', '박응용', '이지스퍼블리싱', '컴퓨터/IT', '코딩을 처음 배우는 중·고등학생과 나만의 경쟁력을 갖추고 싶은 문과생, 소프트웨어 시대에 대비하여 새로운 스펙을 준비하려는 직장인까지! 모두 ‘점프 투 파이썬’으로 프로그래밍을 시작했다!\r\n\r\n파이썬 3버전을 기준으로 집필된 《Do it! 점프 투 파이썬》은 첫째마당에서 실생활 속 사례를 접목해 머리에 쏙쏙 박히는 문법 설명을 읽은 후 예제로 익히고, 둘째마당에서 스스로 프로그램을 만들 수 있는 실력 키우기 훈련을 거친다. 이 책과 함께 하루 한 시간, 한 달이면 누구나 초보 딱지 떼고 파이썬 프로그래밍을 정복할 수 있다!', '불가', 'Non', 'C열 5-3', 'http://ljh5432.iptime.org:5000/b40a8e62-ae58-45d0-bb9d-1d8f16252add.png', '점프 투 파이썬.png'),
	(8, '아쿠아맨 Vol.1:침몰', '댄 애브넷', '시공그래픽노블', '그래픽노블', '아틀란티스의 왕 아쿠아맨은 여전히 육지와 해저, 두 세계 사이의 다리가 되기 위해 노력하고 있다. 대립하는 육지와 해저의 관계를 중재하려는 바다의 왕을, 복수심에 불타는 숙적 블랙 만타는 내버려두지 않는다. 블랙 만타가 두 세계의 화평을 도모하는 자리에 나타나 테러를 일으키자 아틀란티스에 대한 지상의 반감은 커져만 가는데...', '불가', 'Non', 'A열 5-1', 'http://ljh5432.iptime.org:5000/fce77b26-1e53-478d-b01a-8a8096668199.jpg', '8952793498_1 (1).jpg'),
	(10, '아쿠아맨 Vol.2:디 아더스', '제프 존스', '시공그래픽노블', '그래픽노블', '지구 표면 대부분을 덮고 있는 거대한 대양, 아쿠아맨은 이를 지배하는 바다의 군주이다. 그러나 육지인들은, 비록 아쿠아맨과 그의 치명적인 연인 메라가 자신들을 지켜 줌에도 불구하고 그를 인정하지 않는다. 인간은 바다를 가벼이 여기듯 아쿠아맨 역시 깔보고 우습게 여긴다. 지상의 인간은 아쿠아맨을 원하지 않는다. 그래도 육지인들에겐 그가 필요했다. \r\n\r\n아쿠아맨 외에도 파도 아래 군림하는 이들이 있었다. 어느 날 해구가 열리고 깊고 어두컴컴한 곳, 빛 한 줄기 닿지 않고 오직 굶주림과 증오만이 가득한 그곳에서 새로운 위험이 수면 위로 올라와 뭍을 덮친다. 실체를 드러낸 공포 앞에서 아쿠아맨은 선택의 기로에 놓인다. 하나의 종을 살리기 위해 또 다른 종을 절멸시켜야 하는 상황에 놓인 그는 과연 어떤 길을 택할 것인가….', '불가', 'Non', 'A열 5-2', 'http://ljh5432.iptime.org:5000/fd38d879-bc21-471e-9eeb-b1b59e3927bf.jpg', '8952779274_1.jpg'),
	(11, 'DC 아쿠아맨 아트북', '마이크 아빌라', '아르누보', '잡지/화보', '〈아쿠아맨〉 영화 개봉에 맞춰 출간되는 《아쿠아맨 아트북》은 기존의 DC팬들은 물론, 새로이 유입될 팬들을 만족시킬 아쿠아맨의 모든 것을 담고 있다. 영화는 화려한 볼거리와 흥미진진한 스토리와 웃음으로 무장했다면 《아쿠아맨 아트북》은 책에서만 볼 수 있는 배우들의 인터뷰와 제작 비하인드 스토리 등 많은 이야기들을 담았다.', '가능', 'Non', 'A열 5-3', 'http://ljh5432.iptime.org:5000/80c47216-589a-4142-b91b-fca134371a55.jpg', 'k202534618_1.jpg'),
	(12, '아쿠아맨 Vol.3 : 아틀란티스의 왕좌 ', '제프 존스', '시공그래픽노블', '그래픽노블', '수수께끼의 세력이 아틀란티스와 육지 세계 사이에 전쟁을 부추긴다. 어떤 이유에선지 육지에서 발사된 미사일에 폭격을 당한 아틀란티스는 이를 공격으로 받아들여 전면 대응에 나선다. 아틀란티스의 왕이자 아쿠아맨의 동생인 옴은 선두에 서서 메트로폴리스와 고담을 비롯한 육지 곳곳을 침몰시킨다. 무수한 희생자가 발생하고, 한때 아틀란티스의 왕이었으나 이제 저스티스 리그의 입장에서 혈육과 동족을 마주한 아쿠아맨은 큰 갈등에 빠진다. \r\n\r\n그런 그의 반응을 이해하지 못하는 저스티스 리그의 동료들은 무력으로 대항하지 않으려는 아쿠아맨과 대립하게 되는데…! 해저에는 동생을, 지상에는 동료를 가진 아쿠아맨은 과연 서로간의 오해를 종식시키고 싸움을 멈출 수 있을 것인가?!', '가능', 'Non', 'A열 5-4', 'http://ljh5432.iptime.org:5000/8bb5d59f-7869-4aa8-a86e-f906c4a2d4c2.jpg', '8952790189_1.jpg'),
	(13, '아쿠아맨 Vol.4 : 왕의 죽음', '제프 존스', '시공그래픽노블', '그래픽노블', '아틀란티스와 지상 세계가 벌인 전쟁이 끝나고, 전쟁을 선동한 자들은 모두 갇힌다. 세계는 잠시나마 불안정한 평화를 누린다. 아쿠아맨으로 알려진 슈퍼 히어로, 아서 커리는 왕의 신분으로 아틀란티스를 통치한다. 그러나 그 통치는 시작도 하기 전에 끝날 위기를 맞는다. \r\n\r\n아틀란티스 내부에서는 아쿠아맨의 심복 중 일부가 아서를 왕좌에서 끌어내리고 호전적인 그의 동생 옴을 새로운 왕으로 추대할 음모를 꾸민다. 바다 어딘가에서는 핵잠수함 선단을 이끄는 악당 스캐빈저가 아틀란티스의 무기를 끌어 모아 세계 곳곳에 흩뿌린다. 그의 꿍꿍이는 과연 무엇일까?\r\n', '가능', 'Non', 'A열 6-5', 'http://ljh5432.iptime.org:5000/a61dcb54-4eb8-4b1d-9ad5-db46d9441ba2.jpg', '8952790197_1.jpg'),
	(14, '아쿠아맨 Vol.1 : 해구 괴물 ', '제프 존스', '시공그래픽노블', '그래픽노블', '지구 표면 대부분을 덮고 있는 거대한 대양, 아쿠아맨은 이를 지배하는 바다의 군주이다. 그러나 육지인들은, 비록 아쿠아맨과 그의 치명적인 연인 메라가 자신들을 지켜 줌에도 불구하고 그를 인정하지 않는다. 인간은 바다를 가벼이 여기듯 아쿠아맨 역시 깔보고 우습게 여긴다. 지상의 인간은 아쿠아맨을 원하지 않는다. 그래도 육지인들에겐 그가 필요했다. \r\n\r\n아쿠아맨 외에도 파도 아래 군림하는 이들이 있었다. 어느 날 해구가 열리고 깊고 어두컴컴한 곳, 빛 한 줄기 닿지 않고 오직 굶주림과 증오만이 가득한 그곳에서 새로운 위험이 수면 위로 올라와 뭍을 덮친다. 실체를 드러낸 공포 앞에서 아쿠아맨은 선택의 기로에 놓인다. 하나의 종을 살리기 위해 또 다른 종을 절멸시켜야 하는 상황에 놓인 그는 과연 어떤 길을 택할 것인가….', '가능', 'Non', 'A열 5-6', 'http://ljh5432.iptime.org:5000/660a6a61-490f-4ce1-b054-efeef1c68192.jpg', '8952777735_1.jpg'),
	(17, '뇌를 자극하는 ASP.NET 2.0', '이시환', '한빛미디어', '컴퓨터/IT', '반복적인 코딩 작업은 이제 그만! 코드량을 최대 70%까지 확~줄여줍니다.\nASP.NET 2.0의 개념부터 상세하고 친절하게 알려주어 웹 프로그래밍 경험이 없는 독자도 쉽게 웹 프로그래밍을 시작할 수 있다. ASP.NET 2.0이 지향하는 Codeless(코드량을 혁신적으로 줄인 개발 방법)에 맞춘 예제들은 생산성을 높이는 방법을 일깨워준다. 매번 웹 사이트를 구현할 때마다 똑같은 삽질을 하고 있다는 자괴감에 빠진 개발자에게는 더욱 안성맞춤이다. 중요한 대목에서는 예제만 살펴보고 끝내지 않는다. 호기심을 자극하는 ‘비타민 퀴즈’, 머리 속이 깔끔하게 정리되는 ‘실습문제’를 낸다. 이 책을 읽다 보면 개발자의 수고를 획기적으로 덜어주는 "친절한" ASP.NET 2.0을 만나게 될 것이다.', '가능', 'Non', 'A열 5-8', 'http://ljh5432.iptime.org:5000/3ae5747c-110b-4513-9cc7-2e4ae6e6a071.png', '뇌를 자극하는 ASP.NET 2.0 프로그래밍.png'),
	(23, '로마의 일인자1', '콜린 매컬로', '교유서가', '역사소설', '3천만 부가 팔리며 세계적인 베스트셀러가 됐던 장편소설 <가시나무새>의 작가 콜린 매컬로가 여생을 걸고 쓴 대작 "마스터스 오브 로마" 시리즈 제1부. 이 시리즈는 작가가 자료를 모으고 고증하는 데만 13년이 걸렸고, 이후 집필을 시작해 시력을 잃어가며 완결하기까지 근 20년이 걸렸다.\r\n', '가능', 'Non', 'B열 3-1', 'http://ljh5432.iptime.org:5000/23ba45db-6c36-4811-ad10-5f54fd0355a8.jpg', '8954636888_2.jpg'),
	(24, '로마의 일인자2', '콜린 매컬로', '교유서가', '역사소설', '3천만 부가 팔리며 세계적인 베스트셀러가 됐던 장편소설 <가시나무새>의 작가 콜린 매컬로가 여생을 걸고 쓴 대작 "마스터스 오브 로마" 시리즈 제1부. 이 시리즈는 작가가 자료를 모으고 고증하는 데만 13년이 걸렸고, 이후 집필을 시작해 시력을 잃어가며 완결하기까지 근 20년이 걸렸다.\r\n\r\n', '가능', 'Non', 'B열 3-2', 'http://ljh5432.iptime.org:5000/93884e12-de4d-44b4-8eb5-efa3abeafe72.jpg', '8954636896_2.jpg'),
	(25, '로마의 일인자3', '콜린 매컬로', '교유서가', '역사소설', '3천만 부가 팔리며 세계적인 베스트셀러가 됐던 장편소설 <가시나무새>의 작가 콜린 매컬로가 여생을 걸고 쓴 대작 "마스터스 오브 로마" 시리즈 제1부. 이 시리즈는 작가가 자료를 모으고 고증하는 데만 13년이 걸렸고, 이후 집필을 시작해 시력을 잃어가며 완결하기까지 근 20년이 걸렸다.\r\n', '가능', 'Non', 'B열 3-3', 'http://ljh5432.iptime.org:5000/6078c5b0-0251-4654-9e60-daa7395c2934.jpg', '895463690x_2.jpg'),
	(26, '(뉴52) 저스티스 리그 1: 탄생', '제프 존스', '시공그래픽노블', '그래픽노블', '주요 캐릭터들이 전부 나오기 때문에 <뉴 52! 저스티스 리그 Vol. 1: 탄생>은 뉴 52!를 처음으로 접하기에 가장 적합한 작품이다. 특히 리부트 이후 각 히어로마다 성격에 크고 작은 변화가 생겼는데 이를 보는 재미가 상당하다. DC 코믹스는 뉴 52! \r\n', '가능', 'Non', 'C열 1-2', 'http://ljh5432.iptime.org:5000/660f302a-3d53-4a16-97e1-f8ea9e25ef5e.jpg', '8952775589_1.jpg'),
	(27, '(뉴52) 저스티스 리그 1: 탄생', '제프 존스', '시공그래픽노블', '그래픽노블', '주요 캐릭터들이 전부 나오기 때문에 <뉴 52! 저스티스 리그 Vol. 1: 탄생>은 뉴 52!를 처음으로 접하기에 가장 적합한 작품이다. 특히 리부트 이후 각 히어로마다 성격에 크고 작은 변화가 생겼는데 이를 보는 재미가 상당하다. DC 코믹스는 뉴 52! \r\n', '가능', 'Non', 'C열 1-3', 'http://ljh5432.iptime.org:5000/660f302a-3d53-4a16-97e1-f8ea9e25ef5e.jpg', '8952775589_1.jpg'),
	(28, '(뉴52) 저스티스 리그 1: 탄생', '제프 존스', '시공그래픽노블', '그래픽노블', '주요 캐릭터들이 전부 나오기 때문에 <뉴 52! 저스티스 리그 Vol. 1: 탄생>은 뉴 52!를 처음으로 접하기에 가장 적합한 작품이다. 특히 리부트 이후 각 히어로마다 성격에 크고 작은 변화가 생겼는데 이를 보는 재미가 상당하다. DC 코믹스는 뉴 52! \r\n', '가능', 'Non', 'C열 1-4', 'http://ljh5432.iptime.org:5000/660f302a-3d53-4a16-97e1-f8ea9e25ef5e.jpg', '8952775589_1.jpg'),
	(29, '(뉴 52)배트맨 이터널 1', '제임스 타이니언4세', '시공그래픽노블', '그래픽노블', '뉴욕타임스 베스트셀러 작가 스콧 스나이더가 제임스 타이니언 4세와 함께 각본을 쓴 <배트맨 이터널> #1-21 수록. 각본 작업에 레이 포크스와 존 레이먼, 팀 실리가 참여했으며, 작화가로 제이슨 파보크, 더스틴 윈, 길렌 마치, 미켈 하닌, 앤디 클라크, 트레버 매카시, 이마뉴엘 시미오니, 리카르도 부르키엘리, 이언 버트램 등이 참여했다.', '불가', 'Non', 'D열 1-1', 'http://ljh5432.iptime.org:5000/1484deb4-698f-4154-8258-fb0e6343f6a3.jpg', '8952781902_1.jpg'),
	(30, '(뉴 52)배트맨 이터널 1', '제임스 타이니언4세', '시공그래픽노블', '그래픽노블', '뉴욕타임스 베스트셀러 작가 스콧 스나이더가 제임스 타이니언 4세와 함께 각본을 쓴 <배트맨 이터널> #1-21 수록. 각본 작업에 레이 포크스와 존 레이먼, 팀 실리가 참여했으며, 작화가로 제이슨 파보크, 더스틴 윈, 길렌 마치, 미켈 하닌, 앤디 클라크, 트레버 매카시, 이마뉴엘 시미오니, 리카르도 부르키엘리, 이언 버트램 등이 참여했다.', '가능', 'Non', 'D열 1-2', 'http://ljh5432.iptime.org:5000/1484deb4-698f-4154-8258-fb0e6343f6a3.jpg', '8952781902_1.jpg'),
	(31, '(뉴 52)배트맨 이터널 1', '제임스 타이니언4세', '시공그래픽노블', '그래픽노블', '뉴욕타임스 베스트셀러 작가 스콧 스나이더가 제임스 타이니언 4세와 함께 각본을 쓴 <배트맨 이터널> #1-21 수록. 각본 작업에 레이 포크스와 존 레이먼, 팀 실리가 참여했으며, 작화가로 제이슨 파보크, 더스틴 윈, 길렌 마치, 미켈 하닌, 앤디 클라크, 트레버 매카시, 이마뉴엘 시미오니, 리카르도 부르키엘리, 이언 버트램 등이 참여했다.', '가능', 'Non', 'D열 1-3', 'http://ljh5432.iptime.org:5000/1484deb4-698f-4154-8258-fb0e6343f6a3.jpg', '8952781902_1.jpg'),
	(32, '월드 오브 워크래프트 아서스 : 리치왕의 탄생', '크림스티 골든', '제우미디어', '소설', '세계적으로 유명한 블리자드의 MMORPG <월드 오브 워크래프트>의 세계관을 바탕으로 쓰여진 소설. 게임 속 방대한 스토리와 세계관 중 많은 사람들이 궁금해 하는 리치 왕과 강력한 룬검 서리한의 이야기가 담겨 있다.', '가능', 'Non', 'D열 3-3', 'http://ljh5432.iptime.org:5000/6190e067-de35-49c6-94f2-d94ebdc498c9.jpg', '8959522058_1.jpg'),
	(33, '월드 오브 워크래프트 호드의 탄생', '크림스티 골든', '제우미디어', '소설', '월드 오브 워크래프트를 제대로 즐기는 사람들이라면 왜 이 싸움이 시작되었는지에 대해 궁금증을 품었을 것이다. 특히나 이종족으로 이뤄진 호드는 어떻게 만들어졌으며, 왜 아제로스로 오게 된 걸까? \r\n', '가능', 'Non', 'D열 3-4', 'http://ljh5432.iptime.org:5000/9947ce26-318f-4620-8667-b16653ad6d5c.jpg', '8959525197_1.jpg'),
	(34, '월드 오브 워크래프트 공식 요리책', '첼시 먼로 카셀', '아르누보', '생활요리', '블리자드 엔터테인먼트의 인기 게임인 〈월드 오브 워크래프트〉를 즐긴 유저라면 누구나 궁금해했을 게임 속의 다양한 요리들의 레시피를 담았다. 요리 연구가가 직접 저술한 이 책에는 호드와 얼라이언스의 섬세한 요리법들이 모두 담겨 있으며, 이제 막 수습 요리사 딱지를 단 여러분에게 아제로스 세계에서 먹고 마시는 요리들을 만드는 방법을 알려준다.\r\n\r\n', '가능', 'Non', 'D열 3-5', 'http://ljh5432.iptime.org:5000/ab4be14c-5946-4ba2-94e1-ddd7c1ade7d1.jpg', 'k262533743_1.jpg'),
	(35, '열혈강의 C프로그래밍', '윤성우', '프리렉', '컴퓨터/IT', '이 책은 단순히 학습자에게 프로그래밍에 대한 흥미를 붙여드리기 위한 목적으로 집필된 것이 아니라 C 언어를 공부하는데 있어서 정확한 이해를 돕기 위한 목적으로 집필된 책입니다. 물론 흥미를 붙여드리기 위해서 여러 가지로 신경을 쓰긴 했지만 그것이 내용의 주를 이루지는 않습니다. ', '가능', 'Non', 'A열 10-3', 'http://ljh5432.iptime.org:5000/2ee1eea7-69be-45b1-8200-10765915ea82.png', 'C 프로그래밍.png'),
	(36, '월드 오브 워크래프트 부서지는 세계: 대격변의 전조', '크리스티 골든', '제우미디어', '소설', '아서스와 스톰레이지 이후 아제로스의 지각변동(대격변)을 다룬 WOW 3번째 소설. 대지가 꿈틀거리고, 곳곳에서 호드와 얼라이언스를 이간질하는 사건 사고가 터지게 된다. 이에 호드 대족장 스랄은 호드가 아닌, 아제로스 전체를 구원하기 위해 나선다. 과연, 아제로스를 뒤흔드는 미지의 침입자는 누구인가?\r\n\r\n\r\n', '불가', 'Non', 'D열 3-6', 'http://ljh5432.iptime.org:5000/e0cd4e98-b58a-4a68-ab9a-d165188c7836.jpg', '895952235x_1.jpg'),
	(37, '열혈강의 C프로그래밍', '윤성우', '프리렉', '컴퓨터/IT', '이 책은 단순히 학습자에게 프로그래밍에 대한 흥미를 붙여드리기 위한 목적으로 집필된 것이 아니라 C 언어를 공부하는데 있어서 정확한 이해를 돕기 위한 목적으로 집필된 책입니다. 물론 흥미를 붙여드리기 위해서 여러 가지로 신경을 쓰긴 했지만 그것이 내용의 주를 이루지는 않습니다. ', '가능', 'Non', 'A열 10-4', 'http://ljh5432.iptime.org:5000/2ee1eea7-69be-45b1-8200-10765915ea82.png', 'C 프로그래밍.png'),
	(38, '안드로이드 앱 프로그래밍', '정재곤', '이지스퍼블리싱', '컴퓨터/IT', '이 책이 속한 분야\r\n컴퓨터/IT > 모바일프로그래밍 > 안드로이드\r\n컴퓨터/IT > 대학교재\r\n대학교재 > 컴퓨터\r\nㆍ 7년 연속 안드로이드 분야 1위! 전면 개정 5판(안드로이드 8.0 오레오 버전 · 안드로이드 스튜디오 3.0 반영판)이 나왔다!\r\n《Do it! 안드로이드 앱 프로그래밍》의 다섯 번째 전면 개정판이 나왔다. 이번 개정 5판에서는 안드로이드 8.0 버전(오레오)에 맞춰 소스 코드 테스트를 완료했다. ', '가능', 'Non', 'C열 3-1', 'http://ljh5432.iptime.org:5000/e6130d6f-277e-4249-bc66-c0117aefeb6f.png', '안드로이드 앱 프로그래밍.png'),
	(43, 'HTML5+CSS3 웹 표준의 정석', '고경희', '이지퍼블리싱', '컴퓨터/IT', '책소개\r\n이 책이 속한 분야\r\n컴퓨터/IT > 웹프로그래밍 > HTML/CSS3\r\n컴퓨터/IT > 대학교재\r\n대학교재 > 컴퓨터\r\n문과생도, 중학생도 쉽게 배우는 책, 웹 분야 1위 도서인 《Do it! HTML5+CSS3 웹 표준의 정석》이 전면 개정판으로 돌아왔다. 초판보다 더 쉽고 더 실용적인 예제는 물론, 중학생도 이해하는 쉬운 설명에 최신 표준이 반영되었다. ', '가능', 'Non', 'A열 5-1', 'http://ljh5432.iptime.org:5000/4b43a07c-4a0c-49a0-ad01-28d97fc63b31.png', 'HTML5 CSS3 웹 표준의 정석.png'),
	(44, 'HTML5+CSS3 웹 표준의 정석', '고경희', '이지퍼블리싱', '컴퓨터/IT', '책소개\r\n이 책이 속한 분야\r\n컴퓨터/IT > 웹프로그래밍 > HTML/CSS3\r\n컴퓨터/IT > 대학교재\r\n대학교재 > 컴퓨터\r\n문과생도, 중학생도 쉽게 배우는 책, 웹 분야 1위 도서인 《Do it! HTML5+CSS3 웹 표준의 정석》이 전면 개정판으로 돌아왔다. 초판보다 더 쉽고 더 실용적인 예제는 물론, 중학생도 이해하는 쉬운 설명에 최신 표준이 반영되었다. ', '불가', 'Non', 'A열 5-2', 'http://ljh5432.iptime.org:5000/4b43a07c-4a0c-49a0-ad01-28d97fc63b31.png', 'HTML5 CSS3 웹 표준의 정석.png'),
	(45, 'HTML5+CSS3 웹 표준의 정석', '고경희', '이지퍼블리싱', '컴퓨터/IT', '책소개\r\n이 책이 속한 분야\r\n컴퓨터/IT > 웹프로그래밍 > HTML/CSS3\r\n컴퓨터/IT > 대학교재\r\n대학교재 > 컴퓨터\r\n문과생도, 중학생도 쉽게 배우는 책, 웹 분야 1위 도서인 《Do it! HTML5+CSS3 웹 표준의 정석》이 전면 개정판으로 돌아왔다. 초판보다 더 쉽고 더 실용적인 예제는 물론, 중학생도 이해하는 쉬운 설명에 최신 표준이 반영되었다. ', '가능', 'Non', 'A열 5-3', 'http://ljh5432.iptime.org:5000/4b43a07c-4a0c-49a0-ad01-28d97fc63b31.png', 'HTML5 CSS3 웹 표준의 정석.png'),
	(46, 'Java의 정석', '남궁성', '도우출판', '컴퓨터/IT', '책소개\r\n이 책이 속한 분야\r\n컴퓨터/IT > 프로그래밍 언어 > Java\r\n컴퓨터/IT > 대학교재\r\n대학교재 > 컴퓨터\r\n자바의 기초부터 실전활용까지 모두 담다!\r\n자바의 기초부터 객제지향개념을 넘어 실전활용까지 수록한『Java의 정석』. 저자의 오랜 실무경험과 강의한 내용으로 구성되어 자바를 처음 배우는 초보자들의 궁금한 점을 빠짐없이 담고 있다. ', '가능', 'Non', 'E열 6-3', 'http://ljh5432.iptime.org:5000/88db3886-0cec-4a5d-9423-24f49b45ba5c.png', 'JAVA의 정석.png'),
	(47, 'Java의 정석', '남궁성', '도우출판', '컴퓨터/IT', '책소개\r\n이 책이 속한 분야\r\n컴퓨터/IT > 프로그래밍 언어 > Java\r\n컴퓨터/IT > 대학교재\r\n대학교재 > 컴퓨터\r\n자바의 기초부터 실전활용까지 모두 담다!\r\n자바의 기초부터 객제지향개념을 넘어 실전활용까지 수록한『Java의 정석』. 저자의 오랜 실무경험과 강의한 내용으로 구성되어 자바를 처음 배우는 초보자들의 궁금한 점을 빠짐없이 담고 있다. ', '가능', 'Non', 'E열 6-4', 'http://ljh5432.iptime.org:5000/88db3886-0cec-4a5d-9423-24f49b45ba5c.png', 'JAVA의 정석.png'),
	(48, 'Java의 정석', '남궁성', '도우출판', '컴퓨터/IT', '책소개\r\n이 책이 속한 분야\r\n컴퓨터/IT > 프로그래밍 언어 > Java\r\n컴퓨터/IT > 대학교재\r\n대학교재 > 컴퓨터\r\n자바의 기초부터 실전활용까지 모두 담다!\r\n자바의 기초부터 객제지향개념을 넘어 실전활용까지 수록한『Java의 정석』. 저자의 오랜 실무경험과 강의한 내용으로 구성되어 자바를 처음 배우는 초보자들의 궁금한 점을 빠짐없이 담고 있다. ', '가능', 'Non', 'E열 6-5', 'http://ljh5432.iptime.org:5000/88db3886-0cec-4a5d-9423-24f49b45ba5c.png', 'JAVA의 정석.png'),
	(49, '월드 오브 워크래프트 스톰레이지', '리처드 A 나크', '제우미디어', '소설', '<월드 오브 워크래프트 아서스>에 이은 두 번째 영웅 이야기. 말퓨리온 스톰레이지의 이야기를 다룬 "월드 오브 워크래프트" 두 번째 소설이다. 에메랄드의 꿈이 타락하면서 대드루이드 말퓨리온 스톰레이지가 죽어가고 있다. 그를, 아제로스를 구하기 위한 퀘스트가 시작된다.', '불가', 'Non', 'D열 2-1', 'http://ljh5432.iptime.org:5000/f0212c76-de4d-47a0-81fa-3512139fe052.jpg', '8959522309_1.jpg'),
	(50, '월드 오브 워크래프트 스톰레이지', '리처드 A 나크', '제우미디어', '소설', '<월드 오브 워크래프트 아서스>에 이은 두 번째 영웅 이야기. 말퓨리온 스톰레이지의 이야기를 다룬 "월드 오브 워크래프트" 두 번째 소설이다. 에메랄드의 꿈이 타락하면서 대드루이드 말퓨리온 스톰레이지가 죽어가고 있다. 그를, 아제로스를 구하기 위한 퀘스트가 시작된다.', '가능', 'Non', 'D열 3-2', 'http://ljh5432.iptime.org:5000/f0212c76-de4d-47a0-81fa-3512139fe052.jpg', '8959522309_1.jpg'),
	(54, 'Angular Development with TypeScript', '야코프 페인', '루비페이퍼', '컴퓨터/IT', '1장에서는 개발자들이 많이 사용하는 JavaScript 프레임워크와 라이브러리에 대해 알아보고, Angular 프레임워크의 구조를 전반적으로 살펴본다. \n2장에서는 간단한 Angular 애플리케이션을 만들어보고, 이어서 Angular 애플리케이션을 구성하는 요소에 대해 알아본다. ', '가능', 'Non', 'B열 3-1', 'http://ljh5432.iptime.org:5000/4269f777-db7f-4b48-84f6-022163cc9611.png', 'Angular Development with TypeScript.png'),
	(55, '도커 컨테이너', '크리스토퍼 네거스', '에이콘출판사', '컴퓨터/IT', '이 책은 도커를 처음 접하는 이들이 도커의 기본 개념과 기능을 쉽게 익힐 수 있도록 실습 중심으로 설명한다. 전체 주제를 총 5부로 나눠서, 컨테이너의 개념과 도커의 설치 및 기본 사용법, 개별 컨테이너를 다루기 위한 여러 가지 기능과 옵션 사용법, 클라우드 환경에서 컨테이너를 관리하는 방법, 오케스트레이션을 이용해 여러 개의 컨테이너를 클러스터로 구성해 사용하는 방법, 컨테이너 이미지 제작 방법 등을 차례대로 소개한다. ', '가능', 'Non', 'C열 1-1', 'http://ljh5432.iptime.org:5000/dd694098-6726-4bad-80b6-611fe572b9ef.png', '도커 컨테이너.png'),
	(56, '이것이 자바다', '신용권', '한빛미디어', '컴퓨터/IT', '15년 이상 자바 언어를 교육해온 자바 전문강사의 노하우를 아낌 없이 담아낸 자바 입문서. 저자 직강의 인터넷 강의와 Q/A를 위한 커뮤니티(네이커 카페)까지 무료로 제공하여 자바 개발자로 가는 길을 안내한다.', '가능', 'Non', 'D열 5-3', 'http://ljh5432.iptime.org:5000/6248e510-d476-4e01-9794-85a02f4ebc5c.png', '이것이 자바다.png'),
	(57, 'JSP 2.3 & Servlet 3.1', '오정원', '혜지원', '컴퓨터/IT', '현재 출판되어 있는 대부분의 JSP 책들이 모델1 기반의 예제들로 구성되어 있는 반면 이 책은 모델2 개발 방법 위주로 구성되어 있으며 모델2 애플리케이션의 구성을 최근 대부분의 JavaEE 애플리케이션 개발에서 표준 프레임워크로 사용되고 있는 Spring Framework 구조와 유사하게 구성하였다. ', '가능', 'Non', 'C열 5-1', 'http://ljh5432.iptime.org:5000/ca88799d-4db8-44f7-ae4e-069a6b8c8ac0.png', 'JSP 2.3 & Servlet 3.1.png'),
	(58, '빠르게 활용하는 파이썬 3.6 프로그래밍', '신호철', '위키북스', '컴퓨터/IT', '처음 프로그래밍을 시작하는 분들에게 파이썬은 매우 적합한 언어이다. C 나 자바 등의 언어에 비해 매우 배우기 쉽고, 윈도우나 유닉스 등 여러 운영체제에서도 큰 수정 없이 잘 동작한다. 이 책은 기초 문법부터 실생활에 유용하게 활용할 수 있는 실전 예제까지 자세하게 설명하고 있어, 파이썬을 처음 접하는 초보자는 물론 중급 이상의 개발 경험자들에게도 충분히 유용한 책이 될 것이다.', '가능', 'Non', 'D열 4-5', 'http://ljh5432.iptime.org:5000/23f63c1c-29b7-43a7-b537-56150c7435f8.png', '빠르게 활용하는 파이썬 3.6 프로그래밍.png'),
	(59, '빠르게 활용하는 파이썬 3.6 프로그래밍', '신호철', '위키북스', '컴퓨터/IT', '처음 프로그래밍을 시작하는 분들에게 파이썬은 매우 적합한 언어이다. C 나 자바 등의 언어에 비해 매우 배우기 쉽고, 윈도우나 유닉스 등 여러 운영체제에서도 큰 수정 없이 잘 동작한다. 이 책은 기초 문법부터 실생활에 유용하게 활용할 수 있는 실전 예제까지 자세하게 설명하고 있어, 파이썬을 처음 접하는 초보자는 물론 중급 이상의 개발 경험자들에게도 충분히 유용한 책이 될 것이다.', '가능', 'Non', 'D열 4-6', 'http://ljh5432.iptime.org:5000/23f63c1c-29b7-43a7-b537-56150c7435f8.png', '빠르게 활용하는 파이썬 3.6 프로그래밍.png'),
	(60, 'Angular Development with TypeScript', '야코프 페인', '루비페이퍼', '컴퓨터/IT', NULL, '가능', 'Non', 'B열 3-2', 'http://ljh5432.iptime.org:5000/f4ae0054-0393-42f1-adb7-48c7f26582ca.png', 'Angular Development with TypeScript.png'),
	(61, 'Angular Development with TypeScript', '야코프 페인', '루비페이퍼', '컴퓨터/IT', NULL, '가능', 'Non', 'B열 3-3', 'http://ljh5432.iptime.org:5000/f4ae0054-0393-42f1-adb7-48c7f26582ca.png', 'Angular Development with TypeScript.png'),
	(62, '김태용의 리눅스 쉘 스크립트 프로그래밍 입문', '김태용', 'JPub', '컴퓨터/IT', '서버뿐만 아니라 최근 이슈가 되고 있는 임베디드 시스템에서도 널리 사용되는 리눅스 OS에서 꼭 알아야 할 필수 요소인 쉘(Shell) 프로그래밍 요소를 학습할 수 있도록 구성한 책이다. ', '가능', 'Non', 'B열 2-3', 'http://ljh5432.iptime.org:5000/be95d7af-837d-403d-b4ec-e157a52a74b6.png', '김태용의 리눅스 쉘 스크립트 프로그래밍 입문.png');
/*!40000 ALTER TABLE `book_info` ENABLE KEYS */;

-- 테이블 gdc3_2.book_rental 구조 내보내기
CREATE TABLE IF NOT EXISTS `book_rental` (
  `rental_number` int(11) NOT NULL AUTO_INCREMENT,
  `book_number` int(11) NOT NULL,
  `user_number` int(11) NOT NULL,
  `rental_day` date NOT NULL DEFAULT curdate(),
  `return_schedule` date NOT NULL DEFAULT (curdate() + interval 14 day),
  `return_day` date DEFAULT NULL,
  `rental_status` int(11) NOT NULL DEFAULT 0,
  PRIMARY KEY (`rental_number`),
  KEY `FK_book_rental_signup` (`user_number`),
  KEY `FK_book_rental_book_info` (`book_number`),
  CONSTRAINT `FK_book_rental_book_info` FOREIGN KEY (`book_number`) REFERENCES `book_info` (`book_number`),
  CONSTRAINT `FK_book_rental_signup` FOREIGN KEY (`user_number`) REFERENCES `signup` (`user_number`)
) ENGINE=InnoDB AUTO_INCREMENT=155 DEFAULT CHARSET=utf8;

-- 테이블 데이터 gdc3_2.book_rental:~91 rows (대략적) 내보내기
/*!40000 ALTER TABLE `book_rental` DISABLE KEYS */;
INSERT INTO `book_rental` (`rental_number`, `book_number`, `user_number`, `rental_day`, `return_schedule`, `return_day`, `rental_status`) VALUES
	(53, 7, 5, '2018-12-26', '2019-01-09', NULL, 2),
	(54, 1, 5, '2018-12-26', '2019-01-09', NULL, 2),
	(55, 8, 5, '2018-12-26', '2019-01-09', NULL, 2),
	(56, 7, 5, '2018-12-26', '2019-01-09', NULL, 2),
	(57, 3, 5, '2018-12-26', '2019-01-09', NULL, 2),
	(58, 2, 5, '2018-12-26', '2019-01-09', NULL, 2),
	(60, 1, 5, '2018-12-26', '2019-01-09', NULL, 2),
	(61, 2, 3, '2018-12-26', '2019-01-09', NULL, 2),
	(62, 2, 5, '2018-12-28', '2019-01-11', NULL, 2),
	(63, 8, 5, '2018-12-28', '2019-01-11', NULL, 2),
	(64, 11, 5, '2018-12-28', '2019-01-11', NULL, 2),
	(67, 13, 5, '2018-12-28', '2018-12-20', NULL, 2),
	(68, 12, 5, '2018-12-28', '2019-01-11', NULL, 2),
	(69, 10, 4, '2018-12-28', '2019-01-11', NULL, 1),
	(70, 14, 4, '2018-12-28', '2019-01-11', NULL, 2),
	(71, 23, 6, '2018-12-28', '2019-01-11', NULL, 2),
	(72, 24, 6, '2018-12-28', '2019-01-11', NULL, 2),
	(73, 25, 6, '2018-12-28', '2019-01-11', NULL, 2),
	(74, 1, 5, '2018-12-31', '2019-01-14', NULL, 2),
	(75, 8, 5, '2018-12-31', '2019-01-14', NULL, 1),
	(76, 44, 4, '2018-12-31', '2019-01-14', NULL, 2),
	(77, 11, 5, '2018-12-31', '2019-01-14', NULL, 2),
	(78, 49, 14, '2018-12-31', '2019-01-14', NULL, 1),
	(79, 11, 5, '2018-12-31', '2019-01-14', NULL, 2),
	(80, 12, 15, '2018-12-31', '2019-01-14', NULL, 2),
	(81, 29, 16, '2019-01-04', '2019-01-18', NULL, 1),
	(82, 50, 17, '2019-01-24', '2019-02-07', NULL, 2),
	(83, 36, 9, '2019-01-24', '2019-02-07', NULL, 1),
	(84, 23, 5, '2019-01-24', '2019-02-07', NULL, 2),
	(85, 23, 5, '2019-01-24', '2019-02-07', NULL, 2),
	(86, 23, 5, '2019-01-24', '2019-02-07', NULL, 2),
	(87, 3, 5, '2019-02-28', '2019-03-14', NULL, 2),
	(88, 3, 5, '2019-02-28', '2019-03-14', NULL, 2),
	(89, 3, 5, '2019-02-28', '2019-03-14', NULL, 2),
	(90, 3, 5, '2019-02-28', '2019-03-14', NULL, 2),
	(91, 3, 5, '2019-02-28', '2019-03-14', NULL, 2),
	(92, 3, 5, '2019-02-28', '2019-03-14', NULL, 2),
	(93, 3, 5, '2019-02-28', '2019-03-14', NULL, 2),
	(94, 3, 5, '2019-02-28', '2019-03-14', NULL, 2),
	(95, 3, 5, '2019-02-28', '2019-03-14', NULL, 2),
	(96, 3, 5, '2019-02-28', '2019-03-14', NULL, 2),
	(97, 3, 5, '2019-02-28', '2019-03-14', NULL, 2),
	(98, 3, 5, '2019-02-28', '2019-03-14', NULL, 2),
	(99, 3, 5, '2019-02-28', '2019-03-14', NULL, 2),
	(100, 3, 5, '2019-02-28', '2019-03-14', NULL, 2),
	(101, 43, 5, '2019-02-28', '2019-03-14', NULL, 2),
	(102, 43, 5, '2019-02-28', '2019-03-14', NULL, 2),
	(103, 43, 5, '2019-02-28', '2019-03-14', NULL, 2),
	(104, 43, 5, '2019-02-28', '2019-03-14', NULL, 2),
	(105, 43, 5, '2019-02-28', '2019-03-14', NULL, 2),
	(106, 46, 5, '2019-02-28', '2019-03-14', NULL, 2),
	(107, 46, 5, '2019-02-28', '2019-03-14', NULL, 2),
	(108, 46, 5, '2019-02-28', '2019-03-14', NULL, 2),
	(109, 46, 5, '2019-02-28', '2019-03-14', NULL, 2),
	(110, 46, 5, '2019-02-28', '2019-03-14', NULL, 2),
	(111, 46, 5, '2019-02-28', '2019-03-14', NULL, 2),
	(112, 46, 5, '2019-02-28', '2019-03-14', NULL, 2),
	(113, 46, 5, '2019-02-28', '2019-03-14', NULL, 2),
	(114, 46, 5, '2019-02-28', '2019-03-14', NULL, 2),
	(115, 46, 5, '2019-02-28', '2019-03-14', NULL, 2),
	(116, 7, 5, '2019-02-28', '2019-03-14', NULL, 2),
	(117, 7, 5, '2019-02-28', '2019-03-14', NULL, 2),
	(118, 7, 5, '2019-02-28', '2019-03-14', NULL, 2),
	(119, 1, 5, '2019-02-28', '2019-03-14', NULL, 2),
	(120, 1, 5, '2019-02-28', '2019-03-14', NULL, 2),
	(121, 1, 5, '2019-02-28', '2019-03-14', NULL, 2),
	(122, 1, 5, '2019-02-28', '2019-03-14', NULL, 2),
	(123, 43, 5, '2019-02-28', '2019-03-14', NULL, 2),
	(124, 3, 14, '2019-03-04', '2019-03-18', NULL, 2),
	(125, 1, 14, '2019-03-04', '2019-03-18', NULL, 2),
	(126, 46, 14, '2019-03-04', '2019-03-18', NULL, 2),
	(127, 43, 14, '2019-03-04', '2019-03-18', NULL, 2),
	(128, 37, 14, '2019-03-04', '2019-03-18', NULL, 2),
	(129, 7, 5, '2019-03-12', '2019-03-26', NULL, 2),
	(130, 13, 5, '2019-03-12', '2019-03-26', NULL, 2),
	(131, 14, 5, '2019-03-12', '2019-03-26', NULL, 2),
	(132, 11, 5, '2019-03-12', '2019-03-26', NULL, 2),
	(133, 12, 5, '2019-03-12', '2019-03-26', NULL, 2),
	(134, 13, 5, '2019-03-12', '2019-03-26', NULL, 2),
	(135, 11, 5, '2019-03-12', '2019-03-26', NULL, 2),
	(136, 13, 5, '2019-03-12', '2019-03-26', NULL, 2),
	(137, 11, 5, '2019-03-12', '2019-03-26', NULL, 2),
	(138, 12, 5, '2019-03-12', '2019-03-26', NULL, 2),
	(139, 13, 5, '2019-03-12', '2019-03-26', NULL, 2),
	(140, 33, 25, '2019-03-14', '2019-03-28', NULL, 2),
	(141, 11, 26, '2019-03-14', '2019-03-28', NULL, 2),
	(142, 7, 27, '2019-03-15', '2019-03-29', NULL, 0),
	(143, 11, 2, '2019-03-15', '2019-03-29', NULL, 2),
	(144, 2, 2, '2019-03-15', '2019-03-29', NULL, 2),
	(145, 13, 2, '2019-03-15', '2019-03-29', NULL, 2),
	(146, 2, 2, '2019-03-15', '2019-03-29', NULL, 2),
	(147, 17, 2, '2019-03-15', '2019-03-29', NULL, 2),
	(148, 14, 2, '2019-03-15', '2019-03-29', NULL, 2),
	(149, 23, 2, '2019-03-15', '2019-03-29', NULL, 2),
	(150, 11, 2, '2019-03-15', '2019-03-29', NULL, 2),
	(151, 12, 2, '2019-03-15', '2019-03-29', NULL, 2),
	(152, 25, 2, '2019-03-15', '2019-03-29', NULL, 2),
	(153, 12, 2, '2019-03-17', '2019-03-31', NULL, 2),
	(154, 60, 25, '2019-03-19', '2019-04-02', NULL, 2);
/*!40000 ALTER TABLE `book_rental` ENABLE KEYS */;

-- 프로시저 gdc3_2.p_book_count_api 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_book_count_api`(
	IN `_book_name` VARCHAR(255)
)
BEGIN

	select title, count(*) COUNT from book_info where title = _book_name;

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_book_info_bookinfo_config_update 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_book_info_bookinfo_config_update`(
	IN `_book_number` int,
	IN `_title` VARCHAR(255),
	IN `_author` VARCHAR(255),
	IN `_publisher` VARCHAR(255),
	IN `_genre` VARCHAR(255),
	IN `_brief_introduction` VARCHAR(255),
	IN `_book_location` VARCHAR(255)
)
BEGIN
	
	update book_info SET 
		title = _title, 
		author = _author, 
		publisher = _publisher, 
		genre = _genre, 
		brief_introduction = _brief_introduction,
		book_location = _book_location 
	where 
		book_number = _book_number;

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_book_info_form_listview 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_book_info_form_listview`()
BEGIN
	
select book_number, availability, title, author, publisher from book_info;

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_book_info_insert_book_rental_update 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_book_info_insert_book_rental_update`(
	IN `_book_number` int,
	IN `_user_number` int
)
BEGIN
	
INSERT INTO book_rental(book_number, user_number) VALUES(_book_number, _user_number); update book_info set availability = '불가' where book_number = _book_number;

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_book_info_listview_click_select_post 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_book_info_listview_click_select_post`(
	IN `_book_number` int
)
BEGIN
	
select * from book_info where book_number = _book_number;

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_book_info_search_category_select_post 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_book_info_search_category_select_post`(
	IN `_search_category` varchar(255),
	IN `_search_text` varchar(255)
)
BEGIN

SET @Query = CONCAT("select * from book_info where ",_search_category, " LIKE ", '''%',_search_text,'%''', ";");

PREPARE stmt FROM  @Query;
execute  stmt;
 
END//
DELIMITER ;

-- 프로시저 gdc3_2.p_book_mgt_register_btn 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_book_mgt_register_btn`(
	IN `_title` VARCHAR(255),
	IN `_author` VARCHAR(255),
	IN `_publisher` VARCHAR(255),
	IN `_genre` VARCHAR(255),
	IN `_book_location` VARCHAR(255),
	IN `_brief_introduction` VARCHAR(255),
	IN `_image_location` VARCHAR(255),
	IN `_image_FileName` VARCHAR(255)
)
BEGIN

	insert into book_info(
		title, 
		author, 
		publisher, 
		genre, 
		book_location, 
		brief_introduction, 
		image_location, 
		image_FileName) 
		VALUES(
		_title, 
		_author, 
		_publisher, 
		_genre, 
		_book_location, 
		_brief_introduction, 
		_image_location, 
		_image_FileName);

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_book_mgt_request_listview_click_select_post 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_book_mgt_request_listview_click_select_post`(
	IN `_request_number` int
)
BEGIN

	select 
		R.request_number, 
		S.user_number, 
		S.name, R.title, 
		R.author, 
		R.publisher, 
		R.genre 
		from signup S inner join Receiving_equest R on (S.user_number = R.user_number and R.request_number = _request_number);

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_common_create_ctl_delay_rental_check 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_common_create_ctl_delay_rental_check`(
	IN `_rental_status` varchar(255)
)
BEGIN

update book_rental set rental_status = _rental_status where rental_number in (select rental_number from book_rental where (TO_DAYS(now()) - TO_DAYS(return_schedule)) > 0 and rental_status <> 2);

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_detail_book_info 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_detail_book_info`(
	IN `_book_name` VARCHAR(255)
)
BEGIN

	select * from book_info where title = _book_name;

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_GetUPDATE_API 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_GetUPDATE_API`(
	IN `_email` VARCHAR(255),
	IN `_Phon` VARCHAR(255),
	IN `_addres` VARCHAR(255),
	IN `_user_number` int
)
BEGIN

	UPDATE signup set email = _email,phone_number = _Phon,address = _addres where user_number = _user_number;
	
END//
DELIMITER ;

-- 프로시저 gdc3_2.p_GetUPDATE_Pass_API 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_GetUPDATE_Pass_API`(
	IN `_passwod` VARCHAR(255),
	IN `_user_number` int
)
BEGIN

	UPDATE signup set passwod = _passwod where user_number = _user_number;
	
END//
DELIMITER ;

-- 프로시저 gdc3_2.p_late_mgt_listview_delay_info 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_late_mgt_listview_delay_info`()
BEGIN

	select S.user_number, S.phone_number, S.name, I.title, I.book_number, R.rental_day, TO_DAYS(now()) - TO_DAYS(R.return_schedule) 연체일 from book_info as I inner join book_rental as R on (I.book_number = R.book_number and TO_DAYS(now()) - TO_DAYS(R.return_schedule) > 0 and R.rental_status <> 2) inner join signup as S on (S.user_number = R.user_number);

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_login_form_PW_Select_API 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_login_form_PW_Select_API`(
	IN `_id` VARCHAR(255)
)
BEGIN

	select passwod  from signup where id = _id;
	
END//
DELIMITER ;

-- 프로시저 gdc3_2.p_Passwod_Check_PW_Select_API 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_Passwod_Check_PW_Select_API`(
	IN `_PWtext` VARCHAR(255),
	IN `_user_number` int
)
BEGIN

	select passwod from signup where passwod = _PWtext && user_number = _user_number;
	
END//
DELIMITER ;

-- 프로시저 gdc3_2.p_rental_info_book_info_update 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_rental_info_book_info_update`(
	IN `_no` int
)
BEGIN

update book_info set availability = '가능' where book_number in (select book_number from book_rental where rental_number = _no and rental_status = 2);

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_rental_info_book_rental_update 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_rental_info_book_rental_update`(
	IN `_no` int
)
BEGIN

update book_rental set rental_status = 2 WHERE rental_number = _no;

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_rental_info_form_GetSelect 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_rental_info_form_GetSelect`(
	IN `_user_number` int
)
BEGIN

	select R.rental_number 대여번호,	I.title 도서명, I.author 저자, I.publisher 출판사, R.rental_day 대여일, R.return_schedule 반납일, case when TO_DAYS(now()) - TO_DAYS(return_schedule) > 0 then '연체됨' when TO_DAYS(now()) - TO_DAYS(return_schedule) <= 0 then '연체안됨' else '' end 연체일, case when R.rental_status = 0 then '대여중' when R.rental_status = 1 then '반납요망' else '' end 상태 from	book_info as I inner join book_rental as R on (I.book_number = R.book_number) WHERE R.user_number = _user_number && (R.rental_status = 1 || R.rental_status = 0);
END//
DELIMITER ;

-- 프로시저 gdc3_2.p_request_book_form_request_register 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_request_book_form_request_register`(
	IN `_title` VARCHAR(255),
	IN `_author` VARCHAR(255),
	IN `_publisher` VARCHAR(255),
	IN `_genre` VARCHAR(255),
	IN `_user_number` int
)
BEGIN


insert into Receiving_equest(title, author, publisher, genre, user_number) values(_title, _author, _publisher, _genre, _user_number);


END//
DELIMITER ;

-- 프로시저 gdc3_2.p_request_listview 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_request_listview`()
BEGIN
	
	select R.request_number, 
		S.user_number, 
		S.name, R.title, 
		R.author, 
		R.publisher,
		R.genre 
		from signup S inner join Receiving_equest R on (S.user_number = R.user_number);

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_request_list_delete 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_request_list_delete`(
	IN `_request_number` int
)
BEGIN

	delete from Receiving_equest where request_number = _request_number;

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_Select_signup_info_Webapi 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_Select_signup_info_Webapi`()
BEGIN

select * from signup;

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_signup_form_GetInsert 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_signup_form_GetInsert`(
	IN `_ID` varchar(255),
	IN `_Pass` varchar(255),
	IN `_Name` varchar(255),
	IN `_Gender` varchar(255),
	IN `_Birth` varchar(255),
	IN `_email` varchar(255),
	IN `_Phon` varchar(255),
	IN `_addres` varchar(255)
)
BEGIN

INSERT INTO signup(id,passwod,name,gender,birthday,email,phone_number,address)  values (_ID,_Pass,_Name,_Gender,_Birth,_email,_Phon,_addres);

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_signup_user_number_GetSelect_API 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_signup_user_number_GetSelect_API`(
	IN `_user` VARCHAR(255)
)
BEGIN

	select * from signup where user_number = _user;
	
END//
DELIMITER ;

-- 프로시저 gdc3_2.p_user_blackList_select_post 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_user_blackList_select_post`(
	IN `_user_number` int
)
BEGIN

SELECT blacklist FROM signup where user_number = _user_number;

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_user_ID_Select_API 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_user_ID_Select_API`(
	IN `_PWtext` VARCHAR(255)
)
BEGIN

	select id from signup where passwod = _PWtext;
	
END//
DELIMITER ;

-- 프로시저 gdc3_2.p_user_info_form_user_info_search 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_user_info_form_user_info_search`(
	IN `_search_category` varchar(255),
	IN `_textbox_search` varchar(255)
)
BEGIN

SET @Query = CONCAT("select * from signup where ",_search_category, " LIKE ", '''%',_textbox_search,'%''', ";");

PREPARE stmt FROM  @Query;
EXECUTE  stmt;
DEALLOCATE PREPARE stmt; 

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_user_info_form_user_rental_info 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_user_info_form_user_rental_info`(
	IN `_user_number` int
)
BEGIN

select	R.rental_number, I.book_number, I.title, I.author, I.publisher, case when R.rental_status = 0 then '대여중' when R.rental_status = 1 then '미반납' end as 'rental_status' from	book_info I inner join	book_rental  R on (R.user_number = _user_number and I.book_number = R.book_number and R.rental_status <> 2);

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_user_info_form_user_signup 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_user_info_form_user_signup`(
	IN `_user_number` int
)
BEGIN

select * from signup where user_number = _user_number;

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_user_level_update_form_signup_blacklist_N_set 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_user_level_update_form_signup_blacklist_N_set`(
	IN `_user_number` int
)
BEGIN

update signup set blacklist = 'N' where user_number = _user_number;

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_user_level_update_form_signup_blacklist_Y_set 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_user_level_update_form_signup_blacklist_Y_set`(
	IN `_user_number` int
)
BEGIN

update signup set blacklist = 'Y' where user_number = _user_number;

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_user_level_update_form_signup_member_rank_0_set 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_user_level_update_form_signup_member_rank_0_set`(
	IN `_user_number` int
)
BEGIN

update signup set member_rank = 0 where user_number = _user_number;

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_user_level_update_form_signup_member_rank_1_set 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_user_level_update_form_signup_member_rank_1_set`(
	IN `_user_number` int
)
BEGIN

update signup set member_rank = 1 where user_number = _user_number;

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_user_level_update_form_user_number_signup_info 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_user_level_update_form_user_number_signup_info`(
	IN `_user_number` int
)
BEGIN

select * from signup where user_number = _user_number;

END//
DELIMITER ;

-- 프로시저 gdc3_2.p_User_Number_Member_Rank_Chk_API 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `p_User_Number_Member_Rank_Chk_API`(
	IN `_id` VARCHAR(255),
	IN `_pw` VARCHAR(255)
)
BEGIN

	select user_number, member_rank from signup where id = _id && passwod = _pw;
	
END//
DELIMITER ;

-- 프로시저 gdc3_2.P_WriteUsers 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `P_WriteUsers`(_id VARCHAR(255), _passwod VARCHAR(255), _name VARCHAR(255), _gender VARCHAR(255), _birthday VARCHAR(255), _email VARCHAR(255), _phone_number VARCHAR(255), _address VARCHAR(255))
BEGIN
	
insert into signup (id, passwod, name, gender, birthday, email, phone_number, address) values (_id, _passwod, _name, _gender, _birthday, _email, _phone_number, _address);
	
END//
DELIMITER ;

-- 테이블 gdc3_2.Receiving_equest 구조 내보내기
CREATE TABLE IF NOT EXISTS `Receiving_equest` (
  `request_number` int(11) NOT NULL AUTO_INCREMENT,
  `user_number` int(11) DEFAULT NULL,
  `title` varchar(255) NOT NULL,
  `author` varchar(255) NOT NULL,
  `publisher` varchar(255) NOT NULL,
  `genre` varchar(255) DEFAULT NULL,
  `Request_date` date DEFAULT curdate(),
  `deleteYN` varchar(50) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`request_number`),
  KEY `FK_Receiving_equest_signup` (`user_number`),
  CONSTRAINT `FK_Receiving_equest_signup` FOREIGN KEY (`user_number`) REFERENCES `signup` (`user_number`)
) ENGINE=InnoDB AUTO_INCREMENT=28 DEFAULT CHARSET=utf8;

-- 테이블 데이터 gdc3_2.Receiving_equest:~8 rows (대략적) 내보내기
/*!40000 ALTER TABLE `Receiving_equest` DISABLE KEYS */;
INSERT INTO `Receiving_equest` (`request_number`, `user_number`, `title`, `author`, `publisher`, `genre`, `Request_date`, `deleteYN`) VALUES
	(18, 6, '배트맨 vol.1 나는 고담이다', '톰킹', '시공그래픽노블', '그래픽노블', '2018-12-31', 'Y'),
	(19, 4, '김태용의 리눅스 쉘 스크립트 프로그래밍 입문', '김태용', 'JPub', '컴퓨터/IT', '2018-12-31', 'Y'),
	(20, 10, '점박이 한반도의 공룡2. 1: 겁쟁이 타르보사우루스', '한상호', '웅진주니어', '유아/그림', '2018-12-31', 'Y'),
	(21, 11, '우리가 살아 있는 모든 순간', '톰 말름퀴스트', '다산책방', '장편소설', '2018-12-31', 'N'),
	(22, 12, '무작정 따라하기 다낭·호이안·후에', '전상현', '길벗', '여행', '2018-12-31', 'Y'),
	(23, 15, '요청할 도서 제목', '저자', '출판사', 'IT', '2018-12-31', 'Y'),
	(24, 3, '자바스크립트+jQuery', '박성배', '영진닷컴', '컴퓨터/IT', '2019-03-13', 'N'),
	(25, 23, '인사이드 자바스크립트', '송형주', '한빛미디어', '컴퓨터/IT', '2019-03-13', 'N'),
	(27, 26, 'Do it! 웹 사이트 기획 입문', '이정원', '이지스퍼블리싱', '컴퓨터/IT', '2019-03-15', 'N');
/*!40000 ALTER TABLE `Receiving_equest` ENABLE KEYS */;

-- 테이블 gdc3_2.signup 구조 내보내기
CREATE TABLE IF NOT EXISTS `signup` (
  `user_number` int(11) NOT NULL AUTO_INCREMENT,
  `id` varchar(255) NOT NULL,
  `passwod` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `birthday` date DEFAULT '2019-01-06',
  `email` varchar(255) NOT NULL,
  `phone_number` varchar(255) NOT NULL DEFAULT 'NaverMgmt',
  `address` varchar(255) NOT NULL DEFAULT 'NaverMgmt',
  `blacklist` varchar(255) DEFAULT 'N',
  `member_rank` int(11) DEFAULT 1,
  `LoginPass` varchar(100) DEFAULT 'HLC',
  PRIMARY KEY (`user_number`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8;

-- 테이블 데이터 gdc3_2.signup:~26 rows (대략적) 내보내기
/*!40000 ALTER TABLE `signup` DISABLE KEYS */;
INSERT INTO `signup` (`user_number`, `id`, `passwod`, `name`, `gender`, `birthday`, `email`, `phone_number`, `address`, `blacklist`, `member_rank`, `LoginPass`) VALUES
	(1, 'root', 'ZDQxY2E5YjNmZjkzYjI0ZGE0MzljMzJhYjI4YzI0ZmQwMzIyMGZiZWUxM2QzYzQ2NTBmMjAxMjUxNzJhZTcyZA==', '이지현', '남자', '2018-12-17', 'hlc@naver.com', '010-0000-0000', '서울특별시 금천구 가산동 가산디지털2로', 'N', 0, 'HLC'),
	(2, 'Admin', 'NjBmZTc0NDA2ZTdmMzUzZWQ5NzlmMzUwZjJmYmI2YTJlODY5MGE1ZmE3ZDFiMGMzMjk4M2QxZDhiM2Y5NWY2Nw==', '관리자', '남자', '1988-04-27', 'ljh5432@gmail.com', '010-9206-9635', '동대문구 장안1동', 'N', 0, 'HLC'),
	(3, 'user1', 'OWNjMmI2ZjkxYTlhYTg1OGU2NmM0NGViNmI4NmIzNDczZDQ2Y2ZkZTY4Mzc4MDYzZjE2ZTNjYTJmZWVhN2E3NA==', '임한의', '남자', '1995-03-18', 'LoastArk@smile.com', '010-7616-0880', '서울특별시 종로구 삼일대로30길 23 (익선동)', 'N', 1, 'HLC'),
	(4, 'goodee', 'NDFkZGZhMWQ5NjhmZDZmNTc4YWIyYWEyNDdkNjUxMDBlNDhjYmNhMDBmYTExOTIzNThmNmFkNjI4ZWM4Zjg3Mg==', '김남규', '남자', '1988-04-27', 'ljh5432@gmail.com', '010-0000-0000', '동대문구 장안 1동 ', 'N', 0, 'HLC'),
	(5, 'user2', 'ZDNmODlhOWZkZDZhNjBiOTU1NmQ0NjNhYWMwNmRjMTk0ODZiM2E1NTUyMDgwN2FjZTZiMjRiZjlmMjJjZWMwYQ==', '박나래', '남자', '1980-03-18', 'Tiger9@naver.com', '010-3542-0123', '경기도 김포시 김포대로 1009-51 (북변동)', 'N', 1, 'HLC'),
	(6, 'ue88427', 'NjNmYjA4ZmE2NDBlZDY0ZTVkOGE0M2YxOGVkMjkyNTgxMDQ2MmI4ODVkZjJmMmVhNWJhY2Y4MmMzODc2NjZhMg==', '강남', '남자', '1990-03-18', 'ljhser27@water.com', '010-1234-2222', '서울특별시 서초구 강남대로 275 (서초동)', 'N', 1, 'HLC'),
	(9, 'devuser', 'MzZhN2ZlMGVmNmRkMmM5ZDgwOTQ3ZmJlNjIwNjkxMTg4Mjk5NDFkNDM2OTk4MmMyMjM0NmRmY2I3M2Q3MTE2OQ==', '이석훈', '남자', '1995-03-18', 'Hell335@blizard', '010-0000-0000', '서울특별시 성북구 선잠로2라길 27 (성북동)', 'N', 1, 'HLC'),
	(10, 'gdc33', 'NzQ2ZjI1NzlmZjE3NWRhNDBlMzFiZDMzNGExMzE2M2JhNjA3MjIzMjRiMDhjNzQ5NzkzMmYzNzBmM2U3ODljMQ==', '최영진', '남자', '2011-03-31', 'gudi@naver.com', '010-1004-8282', '가산디지털 대륭3차', 'N', 1, 'HLC'),
	(11, 'SlayerS_BoxeR', 'OTRhYmUyMGI4OGIzODc2NzRmYTRhNDI0MGNjYTRlNzY0ODk5Y2QxNGM2YmFjNzY2ODYwODhlYjc3MDEzMTkzYw==', '임요환', '남자', '1980-09-04', 'progamer@naver.com', '010-3455-8777', '관악구', 'N', 1, 'HLC'),
	(12, 'ljh', 'NzQ5YTU2YmZiMmU1NTRlNTcwNDRmMzgyZjZlODc5MDAyZTI5OTZkN2Q5MDQ0ZWNkMjE4MDU1NTdiMjlhYjg4Zg==', '신밧드', '남자', '1955-01-17', 'sinbotte@naver.com', '010-0000-1004', '신림동', 'N', 1, 'HLC'),
	(13, 'admin3', 'MDI1MmExNDRkOWQxZjNmMThkYjBlZGJmOTk4NjVjMGZmZjYxZjRlYjcwMjlkZjU1OWFhYjdiZmVjOTBkNDIyYg==', '관리자3', '여자', '2018-07-04', 'gudi@gmail.com', '010-0000-1234', '가산 디지털단지 3차', 'N', 0, 'HLC'),
	(14, 'gdc2', 'NTQzMGM4YzE3OGQwMDM5MWU5Mzk1YWY2NzRiM2Y0ZGM5NDE3MjUxNDdhMTAyMDAyNzJlNjZjY2YxOTYyMDFkYQ==', '김상록', '남자', '2018-11-02', 'gudiarcademy@naver.com', '010-2223-4685', '구디아카데미 구로디지털단지', 'N', 1, 'HLC'),
	(15, 'gdc3', 'NDIwMWY2NzkwY2Q5NDljYmMyMzZmODdmOTE4NTAzMWIwYWQwOGZmZDdiMWFlMWY2MGM1NjI4M2Q5N2Y3NzA0ZA==', '마동석', '남자', '2018-10-24', 'gudi@naver.com', '010-0000-1111', '가산디지털단지', 'N', 1, 'HLC'),
	(16, 'gdc1', 'OTgxOWRhOGYzODhmMjIwYjY4ZDI4MDNmZmU0MGU1ZTI3OTVhYWQ1ZTk5Yjg4NTcwYTY3YWVjMzFmNTg3MTZlOA==', '나진욱', '남자', '2018-09-17', 'gudi@gmail.com', '010-0000-1111', '가산디지털단지로', 'N', 1, 'HLC'),
	(17, 'test', 'OTM3ZThkNWZiYjQ4YmQ0OTQ5NTM2Y2Q2NWI4ZDM1YzQyNmI4MGQyZjgzMGM1YzMwOGUyY2RlYzQyMmFlMjI0NA==', '정인혜', '남자', '2018-12-18', 'GG@naver.com', '01076160880', '구디아카데미', 'N', 1, 'HLC'),
	(18, 'gian84', 'YmMzM2Q1MzVjNjNiYTk3M2RkYmQ2NmE3ZTBiNDM3MjMxNmM3M2ZhNTA5Y2EyNjU1YzVjYmI5NTljY2FjNTZhOQ==', '기안84', '남자', '1988-04-27', 'ljh5432@gmail.com', '010-9206-9635', '서울시 동대문구 장안1동', 'N', 1, 'HLC'),
	(19, 'user3', 'MDVkM2U5ZjFkZGExMzU3MGM2NDQ0OTE4ZWRjMTg3OWJkOWNkOGMzMWQ2YzQxZDcwMTMxMWIwYmYxMjI1ZDg2OA==', '천호성', '여자', '2017-04-12', 'user3@gmail.com', '010-6542-5223', '가산디지털단지 대륭3차', 'N', 1, 'HLC'),
	(20, 'user4', 'YzVlNDczMDU5MDRlM2M5OGZlYzMyNzA2YzAzYzVmYTRjMjNlNmJkOTgzYjM4ZGIxYzVlZjljNzk2YjUzMzE0Mg==', '형성재', '여자', '2017-04-12', 'user4@gmail.com', '010-6542-5223', '가산디지털단지 대륭3차', 'N', 1, 'HLC'),
	(21, 'user5', 'MGU5MDc1ZGRjYzUzYzgyYjdlMjdmZTE4Y2FiMDM2MWRhZmNjYmE2ZmNmM2M2YjNkODBmYzVlNjkxOTJmNzVjMQ==', '홍마태', '여자', '2015-06-17', 'user5@gmail.com', '010-3442-2223', '가산디지털단지 대륭3차 5호', 'N', 1, 'HLC'),
	(22, 'user6', 'MjMwYmFhODIwZDE5MjgyNGU3ZmI1NDg5YjAwMjQ5YmY5NWUyYzExYmJmZDU2NGNjYTQzOWRhZDcyMjFmMDhjZg==', '홍길동', '여자', '2019-01-09', 'user6@gmail.com', '010-2464-2485', '서울시 종로구 종로1가', 'N', 1, 'HLC'),
	(23, 'user7', 'MDY3NDAwYzJhYTkyYjI3MGUzMzU2ZjkzOWNjY2YyYmQ0MmUwN2E3MzNlZjU1YzBkNTU0NzVlOGY3ZDVjMzZkMg==', '유재석', '남자', '1972-08-14', 'jaesuk@gmail.com', '010-1234-8077', '서울특별시 강남구 도산대로 404 (청담동)', 'N', 1, 'HLC'),
	(24, 'user8', 'YTUyZGE5NTA4YzJhYzI1ZTEzMDM3ZmI3NjRmODE1OGJlZWM5NTU5MmQ1ZjViZWZiNDcyMTcwZDA1ZDExNTRmYQ==', '전현무', '남자', '1850-02-15', 'user8@gmail.com', '010-1850-0215', '서울특별시 종로구 종로 1 (종로1가)', 'N', 1, 'HLC'),
	(25, '37625747', 'OTRjYTMwMWQ1ZmU2ODhmZjViMzY4MjllMWIyMGJjMTQ3YzFkMDljMGRmYjUzMTUzNzQ5Y2NkYjhlNDE1NDlhYw==', '다솜', '남자', '2019-01-06', 'ljh5432@wincomsol.com', '010-0000-8077', '서울특별시 종로구 종로 1 (종로1가)', 'N', 1, 'NAVER'),
	(26, '161366465', 'YjMxMjFiM2Y1ZmJkODRhN2M0ZmZkZTE4MGVhMjVlYjBhYTAwM2VkMWZmZDU5MmVmN2EzMTJmY2I5ODQ1NDU3Ng==', '설현', '남자', '2019-01-06', 'jihyun2246@naver.com', 'NaverMgmt', 'NaverMgmt', 'N', 1, 'NAVER'),
	(27, '133595278', 'NWFkOTc2ZjU0Y2JjZmUzMzNhOGZlOTQ4MjhlMTRmZDE0N2E0YmZkODdlYTdmY2I3ZGExZTdjZDQ1NDhkNjQ1OQ==', '이지현naver', '남자', '2019-01-06', 'studysanta@naver.com', '010-9206-9635', '서울특별시 동대문구 천호대로77길 9 (장안동)', 'N', 0, 'NAVER'),
	(28, 'ljh88427', 'NTdlNjAzOTAyOTJkMjkxZmZhZDNiNWIyNzA3YmExMWVjZTQ5YTBlNGY2YWJhNDYyMDAyZDZlZjA5MjZiOGFlZA==', '김동하', '남자', '2013-03-08', 'dh33@naver.com', '010-6756-1514', '서울특별시 성북구 선잠로2다길 51, 더샵아파트 (성북동)', 'N', 1, 'HLC');
/*!40000 ALTER TABLE `signup` ENABLE KEYS */;

-- 프로시저 gdc3_2.test_p 구조 내보내기
DELIMITER //
CREATE DEFINER=`root`@`%` PROCEDURE `test_p`()
BEGIN
	
select book_number, availability, title, author, publisher from book_info;

END//
DELIMITER ;

/*!40101 SET SQL_MODE=IFNULL(@OLD_SQL_MODE, '') */;
/*!40014 SET FOREIGN_KEY_CHECKS=IF(@OLD_FOREIGN_KEY_CHECKS IS NULL, 1, @OLD_FOREIGN_KEY_CHECKS) */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
